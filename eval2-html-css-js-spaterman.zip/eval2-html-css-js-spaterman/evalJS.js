
// SIMONE PATERMAN

    //   $('button').click(function (event) {
    //     event.preventDefault();
   
    
    
    
    $('button').on ('click', function (){

$(this).css({"background-color": "red"});

    });

    $('button').on ('dblclick', function (){

$ (this).css ({"background-color": "green"})

    });



// });